const pptxgen = require('pptxgenjs');
const { svgToDataUri, safeOuterShadow } = require('/home/oai/skills/slides/pptxgenjs_helpers');

const pptx = new pptxgen();
pptx.layout = 'LAYOUT_WIDE';
pptx.author = 'OpenAI';
pptx.company = 'OpenAI';
pptx.subject = 'Incident Reasoning Agent';
pptx.title = 'Incident Reasoning Agent';
pptx.lang = 'en-US';
pptx.theme = {
  headFontFace: 'Arial',
  bodyFontFace: 'Arial',
  lang: 'en-US'
};

const C = {
  black: '111111',
  dark: '1A1A1A',
  gray: '666666',
  light: 'F3F3F3',
  mid: 'D9D9D9',
  white: 'FFFFFF'
};

function addHeader(slide, title, kicker='') {
  slide.addText(kicker, { x: 0.6, y: 0.35, w: 5.6, h: 0.25, fontFace: 'Arial', fontSize: 11, color: C.gray, bold: false, margin: 0 });
  slide.addText(title, { x: 0.6, y: 0.62, w: 7.2, h: 0.6, fontFace: 'Arial', fontSize: 24, color: C.black, bold: true, margin: 0 });
  slide.addShape(pptx.ShapeType.line, { x: 0.6, y: 1.28, w: 12.0, h: 0, line: { color: C.black, pt: 1.2 } });
}

function addBody(slide, paragraphs, x=0.7, y=1.55, w=6.0, h=4.9) {
  const runs = [];
  paragraphs.forEach((p, i) => {
    runs.push({ text: p });
    if (i < paragraphs.length - 1) runs.push({ text: '\n\n' });
  });
  slide.addText(runs, {
    x, y, w, h,
    fontFace: 'Arial', fontSize: 16, color: C.dark, breakLine: false,
    margin: 0.04, valign: 'top', paraSpaceAfterPt: 10, fit: 'shrink'
  });
}

function addRightPanel(slide, title, items, iconSvg) {
  slide.addShape(pptx.ShapeType.rect, { x: 7.15, y: 1.6, w: 5.45, h: 4.95, fill: { color: C.light }, line: { color: C.mid, pt: 1 } });
  slide.addText(title, { x: 7.45, y: 1.85, w: 4.4, h: 0.3, fontSize: 16, bold: true, color: C.black, margin: 0 });
  if (iconSvg) slide.addImage({ data: svgToDataUri(iconSvg), x: 11.85, y: 1.78, w: 0.4, h: 0.4 });
  items.forEach((item, idx) => {
    const y = 2.35 + idx * 0.88;
    slide.addShape(pptx.ShapeType.ellipse, { x: 7.48, y: y + 0.05, w: 0.18, h: 0.18, fill: { color: C.black }, line: { color: C.black, pt: 0.5 } });
    slide.addText(item, { x: 7.8, y, w: 4.45, h: 0.5, fontSize: 14, color: C.dark, margin: 0, fit: 'shrink' });
  });
}

function box(slide, x, y, w, h, title, body) {
  slide.addShape(pptx.ShapeType.roundRect, { x, y, w, h, rectRadius: 0.08, fill: { color: C.white }, line: { color: C.black, pt: 1 }, shadow: safeOuterShadow('000000', 0.10, 45, 1, 0.5) });
  slide.addText(title, { x: x+0.18, y: y+0.14, w: w-0.36, h: 0.28, fontSize: 13, bold: true, color: C.black, margin: 0, align: 'center' });
  slide.addText(body, { x: x+0.18, y: y+0.46, w: w-0.36, h: h-0.58, fontSize: 11.5, color: C.dark, margin: 0.02, align: 'center', valign: 'mid', fit: 'shrink' });
}

function arrow(slide, x, y, w) {
  slide.addShape(pptx.ShapeType.chevron, { x, y, w, h: 0.35, fill: { color: C.black }, line: { color: C.black, pt: 0.5 } });
}

const iconAgent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="18" y="14" width="28" height="24" rx="4" fill="#111111"/><circle cx="27" cy="26" r="3" fill="#ffffff"/><circle cx="37" cy="26" r="3" fill="#ffffff"/><rect x="26" y="32" width="12" height="2" fill="#ffffff"/><rect x="30" y="8" width="4" height="6" fill="#111111"/><rect x="12" y="42" width="40" height="6" rx="3" fill="#111111"/></svg>`;
const iconGraph = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="10" y="12" width="44" height="40" fill="none" stroke="#111111" stroke-width="4"/><path d="M18 42 L28 32 L36 36 L46 22" fill="none" stroke="#111111" stroke-width="4"/><circle cx="18" cy="42" r="3" fill="#111111"/><circle cx="28" cy="32" r="3" fill="#111111"/><circle cx="36" cy="36" r="3" fill="#111111"/><circle cx="46" cy="22" r="3" fill="#111111"/></svg>`;
const iconFlow = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect x="8" y="20" width="14" height="12" fill="#111111"/><rect x="26" y="20" width="14" height="12" fill="#111111"/><rect x="44" y="20" width="12" height="12" fill="#111111"/><path d="M22 26 H26 M40 26 H44" stroke="#111111" stroke-width="4" fill="none"/></svg>`;

// Slide 1
{
  const s = pptx.addSlide();
  addHeader(s, 'Incident Reasoning Agent', 'Differentiated concept for the hackathon');
  s.addText('An AI agent that investigates incidents like an SRE engineer.', { x: 0.7, y: 1.7, w: 6.1, h: 0.6, fontSize: 22, bold: true, color: C.black, margin: 0 });
  addBody(s, [
    'Instead of only classifying requests, the agent analyzes logs, configuration clues, and contextual signals to generate root cause hypotheses.',
    'The result is a ticket enriched with structured technical reasoning, clear next steps, and evidence that helps teams resolve issues faster.'
  ], 0.7, 2.55, 5.9, 2.8);
  s.addShape(pptx.ShapeType.rect, { x: 7.25, y: 1.75, w: 5.1, h: 3.9, fill: { color: C.light }, line: { color: C.black, pt: 1 } });
  box(s, 7.6, 2.15, 1.25, 1.1, 'Input', 'Incident\nlogs\nimage');
  arrow(s, 8.95, 2.52, 0.6);
  box(s, 9.65, 2.15, 1.45, 1.1, 'Reason', 'Signals\ncorrelated');
  arrow(s, 11.2, 2.52, 0.6);
  box(s, 11.9, 2.15, 1.05, 1.1, 'Act', 'Ticket\nnotify');
  s.addImage({ data: svgToDataUri(iconAgent), x: 9.15, y: 3.6, w: 1.25, h: 1.25 });
  s.addText('Investigates\nnot just routes', { x: 10.55, y: 3.78, w: 1.7, h: 0.8, fontSize: 14, color: C.dark, bold: true, margin: 0, align: 'left' });
  s.addText('Black and white visual style for a fast and clean demo.', { x: 0.7, y: 6.55, w: 5.8, h: 0.3, fontSize: 11, color: C.gray, margin: 0 });
}

// Slide 2
{
  const s = pptx.addSlide();
  addHeader(s, 'Why current triage is not enough', 'The problem');
  addBody(s, [
    'Traditional incident flows capture a report and create a ticket, but they do not explain what is actually failing inside the platform.',
    'Engineers still need to inspect logs, compare environments, validate payloads, and reconstruct the technical story under time pressure.',
    'That manual effort is where delay, inconsistency, and operational cost appear.'
  ]);
  addRightPanel(s, 'What slows teams down', [
    'Signals are fragmented across tools and environments',
    'Tickets often lack technical evidence and useful context',
    'The first responder spends time discovering obvious clues',
    'Resolution depends on who is available, not on a repeatable process'
  ], iconGraph);
}

// Slide 3
{
  const s = pptx.addSlide();
  addHeader(s, 'What makes this solution different', 'Differentiator');
  addBody(s, [
    'Most hackathon solutions will classify incidents and push them into a workflow. This project goes one step further and performs structured technical investigation before the ticket is created.',
    'The agent correlates observable evidence, proposes multiple root cause hypotheses, assigns confidence scores, and recommends the next validation actions.'
  ], 0.7, 1.6, 6.0, 2.8);
  s.addShape(pptx.ShapeType.rect, { x: 7.15, y: 1.7, w: 5.45, h: 4.75, fill: { color: C.white }, line: { color: C.black, pt: 1.2 } });
  s.addText('Traditional triage', { x: 7.45, y: 2.0, w: 2.1, h: 0.3, fontSize: 15, bold: true, color: C.black, margin: 0, align: 'center' });
  s.addText('Reasoning triage', { x: 10.05, y: 2.0, w: 2.1, h: 0.3, fontSize: 15, bold: true, color: C.black, margin: 0, align: 'center' });
  s.addShape(pptx.ShapeType.line, { x: 9.88, y: 1.95, w: 0, h: 3.95, line: { color: C.black, pt: 1 } });
  box(s, 7.45, 2.45, 2.05, 0.95, 'Input', 'Read title\nand severity');
  box(s, 7.45, 3.65, 2.05, 0.95, 'Output', 'Create basic\nticket');
  box(s, 10.15, 2.45, 2.05, 0.95, 'Input', 'Read title\nplus logs and context');
  box(s, 10.15, 3.65, 2.05, 0.95, 'Output', 'Hypotheses\nconfidence\nnext steps');
  s.addText('This is the advantage judges will remember.', { x: 7.5, y: 5.45, w: 4.8, h: 0.3, fontSize: 12, color: C.gray, italic: true, margin: 0, align: 'center' });
}

// Slide 4
{
  const s = pptx.addSlide();
  addHeader(s, 'End to end reasoning flow', 'Core demo sequence');
  s.addShape(pptx.ShapeType.rect, { x: 0.7, y: 1.7, w: 11.95, h: 4.7, fill: { color: C.light }, line: { color: C.black, pt: 1 } });
  const steps = [
    ['1 Submit', 'Reporter sends incident\nand attachment'],
    ['2 Gather', 'Agent reads logs\nand context'],
    ['3 Reason', 'Hypotheses and\nconfidence scores'],
    ['4 Create', 'Ticket enriched with\ntechnical summary'],
    ['5 Notify', 'Team receives\nactionable update'],
    ['6 Close', 'Reporter gets\nresolution message']
  ];
  let x = 0.95;
  steps.forEach((st, idx) => {
    box(s, x, 2.55, 1.55, 1.35, st[0], st[1]);
    if (idx < steps.length - 1) arrow(s, x + 1.63, 3.0, 0.42);
    x += 2.02;
  });
  s.addText('The demo should show each stage in sequence, even with mocked integrations.', { x: 0.9, y: 5.55, w: 6.3, h: 0.3, fontSize: 12, color: C.gray, margin: 0 });
  s.addImage({ data: svgToDataUri(iconFlow), x: 11.6, y: 5.28, w: 0.55, h: 0.55 });
}

// Slide 5
{
  const s = pptx.addSlide();
  addHeader(s, 'Architecture designed for a credible MVP', 'Technical view');
  addBody(s, [
    'The architecture is intentionally simple so the team can build it fast, but it still looks production aware and agentic.',
    'FastAPI exposes the incident endpoint. A reasoning layer interprets signals. Mock integrations create tickets and notifications. All steps are observable and containerized.'
  ], 0.7, 1.6, 5.8, 2.5);
  s.addShape(pptx.ShapeType.rect, { x: 6.95, y: 1.7, w: 5.65, h: 4.85, fill: { color: C.white }, line: { color: C.black, pt: 1 } });
  box(s, 7.2, 2.0, 1.15, 0.95, 'UI', 'Incident\ninput');
  box(s, 8.6, 2.0, 1.35, 0.95, 'API', 'FastAPI\nendpoint');
  box(s, 10.2, 2.0, 1.55, 0.95, 'Agent', 'Reasoning\nengine');
  box(s, 7.45, 3.55, 1.45, 1.0, 'Logs', 'Mock log\nreader');
  box(s, 9.2, 3.55, 1.45, 1.0, 'Ticket', 'Mock ticket\nwriter');
  box(s, 10.95, 3.55, 1.2, 1.0, 'Notify', 'Mock\nalerts');
  s.addShape(pptx.ShapeType.line, { x: 8.35, y: 2.48, w: 0.25, h: 0, line: { color: C.black, pt: 1 } });
  s.addShape(pptx.ShapeType.line, { x: 9.95, y: 2.48, w: 0.25, h: 0, line: { color: C.black, pt: 1 } });
  s.addShape(pptx.ShapeType.line, { x: 10.95, y: 2.95, w: 0, h: 0.6, line: { color: C.black, pt: 1 } });
  s.addShape(pptx.ShapeType.line, { x: 10.95, y: 3.55, w: -2.0, h: 0, line: { color: C.black, pt: 1 } });
  s.addShape(pptx.ShapeType.line, { x: 10.95, y: 3.55, w: -0.3, h: 0, line: { color: C.black, pt: 1 } });
  s.addShape(pptx.ShapeType.line, { x: 10.95, y: 3.55, w: 0.0, h: 0, line: { color: C.black, pt: 1 } });
}

// Slide 6
{
  const s = pptx.addSlide();
  addHeader(s, 'What the judges should see as business value', 'Value proposition');
  addBody(s, [
    'The main message is simple: the agent reduces time spent discovering what already happened and increases time spent fixing the real issue.',
    'Because the output is structured, the same flow can later power dashboards, deduplication, or automated runbook suggestions.'
  ], 0.7, 1.6, 5.9, 2.4);
  s.addShape(pptx.ShapeType.rect, { x: 7.15, y: 1.9, w: 5.3, h: 4.35, fill: { color: C.light }, line: { color: C.black, pt: 1 } });
  s.addText('Manual investigation', { x: 7.5, y: 2.25, w: 2.0, h: 0.3, fontSize: 14, bold: true, color: C.black, margin: 0 });
  s.addShape(pptx.ShapeType.rect, { x: 7.55, y: 2.7, w: 1.15, h: 2.6, fill: { color: C.mid }, line: { color: C.black, pt: 1 } });
  s.addText('Hours', { x: 7.72, y: 5.38, w: 0.8, h: 0.2, fontSize: 11, color: C.dark, margin: 0 });
  s.addText('Reasoning agent', { x: 10.05, y: 2.25, w: 1.8, h: 0.3, fontSize: 14, bold: true, color: C.black, margin: 0 });
  s.addShape(pptx.ShapeType.rect, { x: 10.25, y: 3.6, w: 1.15, h: 1.7, fill: { color: C.black }, line: { color: C.black, pt: 1 } });
  s.addText('Minutes', { x: 10.34, y: 5.38, w: 0.95, h: 0.2, fontSize: 11, color: C.dark, margin: 0 });
  s.addText('Same issue, faster diagnosis, better ticket quality.', { x: 7.5, y: 5.78, w: 4.3, h: 0.25, fontSize: 12, color: C.gray, italic: true, margin: 0, align: 'center' });
}

// Slide 7
{
  const s = pptx.addSlide();
  addHeader(s, 'Demo plan and next evolution', 'How to finish strong');
  addBody(s, [
    'For the video, show one incident file, one log file, the agent response, the generated ticket, and the notification output. That is enough to make the concept believable and complete.',
    'After the hackathon, the same design can grow into real integrations, historical incident retrieval, and automated remediation guidance.'
  ], 0.7, 1.6, 5.9, 2.8);
  addRightPanel(s, 'Strong closing points', [
    'Investigates like an engineer, not like a keyword router',
    'Uses multimodal evidence and structured reasoning',
    'Produces enriched tickets with confidence and next steps',
    'Can evolve into a platform level diagnostic assistant'
  ], iconAgent);
}

pptx.writeFile({ fileName: '/mnt/data/incident_reasoner_assets/presentation/Incident_Reasoning_Agent_Deck.pptx' });
